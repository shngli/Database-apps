<?php
// This assumes gpc_magic_quotes are off
require_once "db.php";

if ( isset($_POST['name']) && isset($_POST['email'])) {
   $n = mysql_real_escape_string($_POST['name']);
   $e = mysql_real_escape_string($_POST['email']);
   $p = 'secret';
   $sql = "INSERT INTO users (email, name, password) 
              VALUES ('$e', '$n', '$p')";
   echo "<p>\n$sql\n</p>\n";
   mysql_query($sql);
}

?>
<p>Add A New User</p>
<form method="post">
<p>Name:
<input type="text" name="name" size="50"></p>
<p>Email:
<input type="text" name="email"></p>
<p><input type="submit" value="Add New"/></p>
</form>
