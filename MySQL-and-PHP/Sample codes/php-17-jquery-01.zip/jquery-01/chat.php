<?php
  session_start();
  if ( isset($_POST['message']) ) {
    if ( !isset ($_SESSION['chats']) ) $_SESSION['chats'] = Array();
    $_SESSION['chats'] [] = $_POST['message'];
  }
?>
<html>
<head>
<script type="text/javascript" src="jquery.min.js">
</script>
</head>
<body>
      <h1>Chat</h1>
      <form method="post" action="chat.php">
      <p>
      <input type="text" name="message" size="60"/>
      <input type="submit" value="Chat"/> 
      </p>
      </form>
      <div id="chatcontent">
          <img src="spinner.gif" alt="Loading..."/>
      </div>
<script type="text/javascript">
function updateMsg() {
  console.log("Made request"); 
  $.ajax({
    url: "chatlist.php",
    cache: false,
    success: function(stuff){
      console.log("Got data back");
      $("#chatcontent").html(stuff);
      setTimeout('updateMsg()', 4000);
    }
  });
  console.log("Register complete"); 
}
updateMsg();
</script>
</body>