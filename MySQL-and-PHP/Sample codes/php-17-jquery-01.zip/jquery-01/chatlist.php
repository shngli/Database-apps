<?php
   session_start();
?>
<pre>
<?php
   sleep(5);
   if ( isset($_SESSION['chats'] ) ) {
        print_r($_SESSION['chats']);
    }
?>
</pre>