<?php   session_start(); ?>
<html>
<head>
<script type="text/javascript" src="jquery.min.js">
</script>
</head>
<body>
<p id="para">Where is the spinner?
  <img id="spinner" src="spinner.gif" height="25" 
      style="vertical-align: middle; display:none;">
</p>
<a href="#" onclick="$('#spinner').toggle();
                     console.log('Toggle');
                     return false;">Toggle</a>

<a href="#" onclick="$('#para').css('background-color', 'red');
                     console.log('Red');
                     return false;">Red</a>

<a href="#" onclick="$('#para').css('background-color', 'green');
                     console.log('Green');
                     return false;">Green</a>
</body>