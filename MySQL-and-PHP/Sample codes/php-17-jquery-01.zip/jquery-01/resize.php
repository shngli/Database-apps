<html>
<head>
<script type="text/javascript" src="jquery.min.js">
</script>
</head>
<body>
<script type="text/javascript">
$(window).resize(function() {
  console.log('.resize() called. width='+
    $(window).width()+' height='+$(window).height());
});
</script>
<p>Here is some awesome page content</p>
</body>