<?php
  sleep(1);
  echo('You sent: '.$_POST['val']);
?>
