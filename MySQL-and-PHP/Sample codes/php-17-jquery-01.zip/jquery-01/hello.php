<html>
<head>
<script type="text/javascript" src="jquery.min.js">
</script>
</head>
<body>
<script type="text/javascript">
$(document).ready(function(){ 
  alert("Hello JQuery World!"); 
  console.log('Hello JQuery..');
});
</script>
<p>Here is some awesome page content</p>
</body>