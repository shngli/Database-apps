<html>
<head>
<script type="text/javascript" src="jquery.min.js">
</script>
<script type="text/javascript">
$(document).ready( function () {
  $.getJSON('api.php', function(data) {
      for (var i = 0; i < data.length; i++) { 
         console.log(data[i].title);
      }
    })
  }
);
</script>
</head>
<body>
<p>Howdy - Lets get a JSON list</p>
</body>