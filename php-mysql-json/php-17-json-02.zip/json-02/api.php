<?php
require_once "db.php";
session_start();
$stmt = $pdo->query("SELECT title, plays, rating, id FROM tracks");
$rows = array();
while ( $row = $stmt->fetch(PDO::FETCH_ASSOC) ) {
  $rows[] = $row;
}

echo json_encode($rows);
?>