<?php
  sleep(2);
  $stuff = array('first' => 'first thing', 'second' => 'second thing');
  echo(json_encode($stuff));
?>
